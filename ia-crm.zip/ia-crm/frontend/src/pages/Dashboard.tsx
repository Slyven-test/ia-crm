import React from 'react';

export default function Dashboard() {
  return (
    <div>
      <h2>Tableau de bord</h2>
      <p>Bienvenue dans votre espace CRM. Utilisez la navigation pour accéder aux recommandations et gérer vos campagnes.</p>
    </div>
  );
}